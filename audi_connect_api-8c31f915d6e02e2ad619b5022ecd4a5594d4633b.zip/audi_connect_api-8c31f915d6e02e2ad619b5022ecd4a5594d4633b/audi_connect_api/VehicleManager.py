"""VehicleManager.py"""

_LOGGER = logging.getLogger(__name__)


class VehicleManager:
    def __init__(self):
        pass

    def initialize(self) -> None:
        pass

    def update_all_vehicles_with_cached_state(self) -> None:
        pass
